# OrderFlow — Phase 1 + Phase 2 + Phase 3

This is the **target system** — the disposable application the analysis
platform (System Understanding → Red Team → Experiment → Observer →
Investigation) will point at. It is NOT the intelligence platform itself.

## Phase 1 — Core flow (done, verified)
## Phase 2 — Observability (done, verified)

See earlier sections below for what these cover.

## Phase 3 — Fault injection (new)

Four internal endpoints let you deliberately break Redis or the database
on command, for a fixed duration, without touching Docker or restarting
anything:

```
POST /internal/fault/redis      {"type": "latency", "value_ms": 300, "duration_sec": 30}
POST /internal/fault/database   {"type": "latency", "value_ms": 300, "duration_sec": 30}
POST /internal/fault/reset
GET  /internal/fault/status
```

`type` is either:
- `"latency"` — adds delay before the operation. If `value_ms` is at or
  above the dependency's configured timeout, it becomes a **real timeout**
  (a genuine exception), not just an artificially slow success.
- `"failure"` — the operation fails immediately, no `value_ms` needed.

Faults **expire automatically** after `duration_sec` — no need to call
`/reset` unless you want to clear it early.

### Why the latency fault is applied where it is

For the database fault, the injected delay happens **while the connection
is still checked out from the pool** — not before acquiring it. That's
deliberate: it means the connection stays "active" (occupying one of the
10 pool slots) for the full delay, which is exactly what causes real pool
pressure once a few concurrent requests are in flight. This is Scenario B
from the spec (DB latency → connections held → pool pressure → queued
requests) actually happening, not just narrated.

### Try it — this is your actual demo mechanic

```bash
# 1. Baseline: confirm things are fast and clean
curl http://localhost:8000/metrics

# 2. Inject 300ms latency into the database for 20 seconds
curl -X POST http://localhost:8000/internal/fault/database \
  -H "Content-Type: application/json" \
  -d '{"type": "latency", "value_ms": 300, "duration_sec": 20}'

# 3. While that's active, fire several concurrent requests (see load_test.py
#    from Phase 1, or just hit /products/{id} a few times quickly) and watch
#    /metrics — mysql.active and mysql.saturation_pct should climb

curl http://localhost:8000/internal/fault/status

# 4. Once you're done, or just wait for it to expire on its own:
curl -X POST http://localhost:8000/internal/fault/reset
```

## Project structure

```
orderflow/
├── docker-compose.yml
├── .env.example
├── mysql/
│   └── init.sql
└── api/
    ├── main.py
    ├── config.py
    ├── database/
    │   └── mysql_client.py
    ├── cache/
    │   └── redis_client.py
    ├── middleware/
    │   └── request_id.py
    ├── telemetry/
    │   ├── context.py
    │   ├── jsonlog.py
    │   └── metrics.py
    ├── faults/
    │   └── state.py
    └── routes/
        ├── health.py
        ├── products.py
        ├── orders.py
        ├── metrics.py
        └── faults.py
```

## What's still deferred

- **`/internal/fault/redis` failure-mode fallback story** (Scenario C —
  Redis dies, app should gracefully fall back to MySQL only) is
  structurally supported already (a `"failure"` fault on Redis will raise,
  and the current code doesn't catch it to fall back — that's a genuine
  gap, not yet a graceful-degradation demo). Decide as a team whether
  that's worth building before the deadline or left as a stretch goal.
- Everything else (Red Team, Experiment orchestration, Investigation,
  dashboard) is a separate system that reads from this one — none of it
  belongs inside OrderFlow itself.

## A modeling note for whoever builds System Understanding

The architecture diagram in the spec shows `Redis -> MySQL` as a
dependency edge. **That edge doesn't literally exist on the network** —
Redis never talks to MySQL. The API talks to both. Model this as two edges
(`API -> Redis`, `API -> MySQL`), with "cache miss falls through to the
database" documented as a *request flow inside the API*, not a service
dependency.


