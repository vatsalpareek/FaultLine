import json
import time
import redis

from config import settings
from telemetry.jsonlog import log_event
from telemetry import metrics
from faults import state as fault_state

_pool = redis.ConnectionPool(
    host=settings.REDIS_HOST,
    port=settings.REDIS_PORT,
    max_connections=settings.REDIS_MAX_CONNECTIONS,
    socket_timeout=settings.REDIS_TIMEOUT_MS / 1000,
    socket_connect_timeout=settings.REDIS_TIMEOUT_MS / 1000,
)
_client = redis.Redis(connection_pool=_pool)


def _apply_injected_fault():
    """Checks whether a fault has been injected against Redis and applies
    it. Small latency just slows the operation down; latency at or beyond
    the configured timeout becomes a real timeout (and therefore triggers
    the existing retry logic below) — this is what makes Scenario A from
    the spec ('Redis latency -> requests slow -> timeouts/errors') happen
    for real instead of being simulated after the fact."""
    fault = fault_state.get_active_fault("redis")
    if fault is None:
        return
    if fault["type"] == "failure":
        raise redis.exceptions.ConnectionError("simulated redis failure (fault injection)")
    if fault["type"] == "latency":
        if fault["value_ms"] >= settings.REDIS_TIMEOUT_MS:
            time.sleep(settings.REDIS_TIMEOUT_MS / 1000)
            raise redis.exceptions.TimeoutError("simulated redis timeout (fault injection)")
        time.sleep(fault["value_ms"] / 1000)


def _with_retries(operation: str, fn, *args, **kwargs):
    """Retries a Redis operation up to REDIS_RETRY_COUNT times on
    connection/timeout errors, and times + logs the whole attempt so a
    slow/failing Redis is visible in both metrics and logs."""
    start = time.time()
    metrics.redis_active(1)
    last_error = None
    retries_used = 0
    is_timeout = False
    try:
        for attempt in range(settings.REDIS_RETRY_COUNT + 1):
            try:
                _apply_injected_fault()
                result = fn(*args, **kwargs)
                latency_ms = (time.time() - start) * 1000
                metrics.record_redis_op(latency_ms, error=False, retries=retries_used)
                log_event(service="api", operation=operation, dependency="redis", latency_ms=latency_ms)
                return result
            except (redis.exceptions.ConnectionError, redis.exceptions.TimeoutError) as e:
                last_error = e
                retries_used += 1
                is_timeout = isinstance(e, redis.exceptions.TimeoutError)
                if attempt < settings.REDIS_RETRY_COUNT:
                    time.sleep(0.05)  # brief backoff before retrying
        latency_ms = (time.time() - start) * 1000
        metrics.record_redis_op(latency_ms, error=True, timeout=is_timeout, retries=retries_used)
        log_event(service="api", operation=operation, dependency="redis", level="ERROR",
                   latency_ms=latency_ms, status="error", error=str(last_error))
        raise last_error
    finally:
        metrics.redis_active(-1)


def ping() -> bool:
    return _with_retries("ping", _client.ping)


def get_product(product_id: int):
    raw = _with_retries("get_product", _client.get, f"product:{product_id}")
    return json.loads(raw) if raw else None


def set_product(product_id: int, product: dict):
    _with_retries(
        "set_product",
        _client.set,
        f"product:{product_id}",
        json.dumps(product),
        ex=settings.REDIS_CACHE_TTL_SECONDS,
    )


def get_all_products():
    raw = _with_retries("get_all_products", _client.get, "products:all")
    return json.loads(raw) if raw else None


def set_all_products(products: list):
    _with_retries(
        "set_all_products",
        _client.set,
        "products:all",
        json.dumps(products),
        ex=settings.REDIS_CACHE_TTL_SECONDS,
    )


def invalidate_product(product_id: int):
    _with_retries("invalidate_product", _client.delete, f"product:{product_id}")
    _with_retries("invalidate_product", _client.delete, "products:all")
