import os


class Settings:
    # API
    API_PORT = int(os.environ.get("API_PORT", "8000"))
    REQUEST_TIMEOUT_MS = int(os.environ.get("REQUEST_TIMEOUT_MS", "5000"))

    # Redis
    REDIS_HOST = os.environ.get("REDIS_HOST", "localhost")
    REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
    REDIS_TIMEOUT_MS = int(os.environ.get("REDIS_TIMEOUT_MS", "1000"))
    REDIS_RETRY_COUNT = int(os.environ.get("REDIS_RETRY_COUNT", "2"))
    REDIS_MAX_CONNECTIONS = int(os.environ.get("REDIS_MAX_CONNECTIONS", "10"))
    REDIS_CACHE_TTL_SECONDS = int(os.environ.get("REDIS_CACHE_TTL_SECONDS", "60"))

    # MySQL
    DB_HOST = os.environ.get("DB_HOST", "localhost")
    DB_PORT = int(os.environ.get("DB_PORT", "3306"))
    DB_USER = os.environ.get("DB_USER", "appuser")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "apppass")
    DB_NAME = os.environ.get("DB_NAME", "orderflow")
    DB_MAX_CONNECTIONS = int(os.environ.get("DB_MAX_CONNECTIONS", "10"))
    DB_QUERY_TIMEOUT_MS = int(os.environ.get("DB_QUERY_TIMEOUT_MS", "5000"))


settings = Settings()
