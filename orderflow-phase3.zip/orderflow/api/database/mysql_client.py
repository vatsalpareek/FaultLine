import time
import mysql.connector
from mysql.connector import pooling, errors
from contextlib import contextmanager

from config import settings
from telemetry.jsonlog import log_event
from telemetry import metrics
from faults import state as fault_state

_pool = None


def _create_pool(retries: int = 10, delay_seconds: int = 3):
    """MySQL's official Docker image briefly restarts itself after its first
    'temporary' boot phase, during which connections are refused for a few
    seconds even though the healthcheck already reported 'healthy'. Retrying
    with a short delay rides out that window instead of crashing."""
    global _pool
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            _pool = pooling.MySQLConnectionPool(
                pool_name="orderflow_db_pool",
                pool_size=settings.DB_MAX_CONNECTIONS,
                host=settings.DB_HOST,
                port=settings.DB_PORT,
                user=settings.DB_USER,
                password=settings.DB_PASSWORD,
                database=settings.DB_NAME,
                connection_timeout=int(settings.DB_QUERY_TIMEOUT_MS / 1000),
            )
            print(f"[mysql_client] Connected to MySQL on attempt {attempt}")
            return
        except errors.Error as e:
            last_error = e
            print(f"[mysql_client] MySQL not ready yet (attempt {attempt}/{retries}): {e}")
            time.sleep(delay_seconds)
    raise last_error


_create_pool()


@contextmanager
def _connection(operation: str):
    """Checks a connection out of the pool, tracks it as 'active' for the
    /metrics endpoint, times the whole operation, and logs the result —
    all in one place so every query gets this for free.

    Also applies any injected database fault: a failure fault raises
    immediately; a latency fault sleeps first, and — if that latency is at
    or beyond the configured query timeout — raises instead of returning,
    simulating a real timeout rather than just an artificially slow
    success. Either way, the connection is held open for the delay, which
    is exactly what causes real pool pressure under concurrent load
    (Scenario B in the spec)."""
    fault = fault_state.get_active_fault("database")
    if fault is not None and fault["type"] == "failure":
        log_event(service="api", operation=operation, dependency="mysql", level="ERROR",
                   status="error", error="simulated database failure (fault injection)")
        raise errors.Error("simulated database failure (fault injection)")

    start = time.time()
    metrics.db_active(1)
    conn = None
    try:
        conn = _pool.get_connection()

        if fault is not None and fault["type"] == "latency":
            if fault["value_ms"] >= settings.DB_QUERY_TIMEOUT_MS:
                time.sleep(settings.DB_QUERY_TIMEOUT_MS / 1000)
                raise errors.Error("simulated database timeout (fault injection)")
            time.sleep(fault["value_ms"] / 1000)

        yield conn
        latency_ms = (time.time() - start) * 1000
        metrics.record_db_op(latency_ms, error=False)
        log_event(service="api", operation=operation, dependency="mysql", latency_ms=latency_ms)
    except errors.PoolError as e:
        latency_ms = (time.time() - start) * 1000
        metrics.record_db_op(latency_ms, error=True)
        log_event(service="api", operation=operation, dependency="mysql", level="ERROR",
                   latency_ms=latency_ms, status="error", error="connection pool exhausted")
        raise
    except Exception as e:
        latency_ms = (time.time() - start) * 1000
        metrics.record_db_op(latency_ms, error=True)
        log_event(service="api", operation=operation, dependency="mysql", level="ERROR",
                   latency_ms=latency_ms, status="error", error=str(e))
        raise
    finally:
        if conn is not None:
            conn.close()
        metrics.db_active(-1)


def ping() -> bool:
    with _connection("ping") as conn:
        conn.ping(reconnect=False)
        return True


def fetch_all_products():
    with _connection("fetch_all_products") as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT id, name, price, stock FROM products")
        rows = cur.fetchall()
        cur.close()
        return rows


def fetch_product(product_id: int):
    with _connection("fetch_product") as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            "SELECT id, name, price, stock FROM products WHERE id = %s", (product_id,)
        )
        row = cur.fetchone()
        cur.close()
        return row


def insert_order(product_id: int, quantity: int):
    with _connection("insert_order") as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            "INSERT INTO orders (product_id, quantity, status) VALUES (%s, %s, 'created')",
            (product_id, quantity),
        )
        conn.commit()
        order_id = cur.lastrowid
        cur.close()
    return fetch_order(order_id)


def fetch_order(order_id: int):
    with _connection("fetch_order") as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            "SELECT id, product_id, quantity, status, created_at FROM orders WHERE id = %s",
            (order_id,),
        )
        row = cur.fetchone()
        cur.close()
        return row
