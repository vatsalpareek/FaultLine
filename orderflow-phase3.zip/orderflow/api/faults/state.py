import threading
import time

_lock = threading.Lock()
_faults = {"redis": None, "database": None}


def set_fault(target: str, fault_type: str, value_ms: int = None, duration_sec: int = 30):
    """fault_type is 'latency' (adds delay, operation still succeeds) or
    'failure' (operation raises an error), matching spec section 9."""
    with _lock:
        _faults[target] = {
            "type": fault_type,
            "value_ms": value_ms,
            "duration_sec": duration_sec,
            "expires_at": time.time() + duration_sec,
        }


def clear_fault(target: str = None):
    with _lock:
        if target:
            _faults[target] = None
        else:
            for key in _faults:
                _faults[key] = None


def get_active_fault(target: str):
    """Returns the fault dict if one is currently active for this target,
    else None. Expiry is checked lazily here — no background thread
    needed, a fault simply stops applying once its time is up."""
    with _lock:
        fault = _faults.get(target)
    if fault and time.time() < fault["expires_at"]:
        return fault
    return None


def status():
    with _lock:
        snapshot = {}
        now = time.time()
        for target, fault in _faults.items():
            if fault and now < fault["expires_at"]:
                snapshot[target] = {**fault, "remaining_sec": round(fault["expires_at"] - now, 1)}
            else:
                snapshot[target] = None
        return snapshot
