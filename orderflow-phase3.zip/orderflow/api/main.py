from fastapi import FastAPI
from routes import health, products, orders, metrics, faults
from middleware.request_id import RequestTrackingMiddleware

app = FastAPI(title="OrderFlow", version="0.3.0")

app.add_middleware(RequestTrackingMiddleware)

app.include_router(health.router)
app.include_router(products.router)
app.include_router(orders.router)
app.include_router(metrics.router)
app.include_router(faults.router)


@app.get("/")
def root():
    return {"service": "OrderFlow", "status": "running"}
