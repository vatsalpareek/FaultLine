import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from telemetry.context import request_id_var
from telemetry.jsonlog import log_event
from telemetry import metrics


class RequestTrackingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        req_id = str(uuid.uuid4())[:8]  # short id, plenty unique for a demo
        request_id_var.set(req_id)

        start = time.time()
        metrics.api_active(1)
        try:
            response = await call_next(request)
            latency_ms = (time.time() - start) * 1000
            is_error = response.status_code >= 500 or response.status_code == 503
            metrics.record_api_request(latency_ms, error=is_error)
            log_event(
                service="api",
                operation=f"{request.method} {request.url.path}",
                latency_ms=latency_ms,
                status="success" if not is_error else "error",
            )
            response.headers["X-Request-ID"] = req_id
            return response
        except Exception as e:
            latency_ms = (time.time() - start) * 1000
            metrics.record_api_request(latency_ms, error=True)
            log_event(
                service="api",
                operation=f"{request.method} {request.url.path}",
                level="ERROR",
                latency_ms=latency_ms,
                status="error",
                error=str(e),
            )
            raise
        finally:
            metrics.api_active(-1)
