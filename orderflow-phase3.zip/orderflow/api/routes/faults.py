from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from faults import state

router = APIRouter(prefix="/internal/fault")


class FaultRequest(BaseModel):
    type: str  # "latency" or "failure"
    value_ms: Optional[int] = None   # required for "latency"
    duration_sec: int = 30


@router.post("/redis")
def inject_redis_fault(req: FaultRequest):
    state.set_fault("redis", req.type, req.value_ms, req.duration_sec)
    return {"target": "redis", "injected": req.dict()}


@router.post("/database")
def inject_database_fault(req: FaultRequest):
    state.set_fault("database", req.type, req.value_ms, req.duration_sec)
    return {"target": "database", "injected": req.dict()}


@router.post("/reset")
def reset_faults():
    state.clear_fault()
    return {"status": "all faults cleared"}


@router.get("/status")
def fault_status():
    return state.status()
