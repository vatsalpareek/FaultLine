from fastapi import APIRouter
from database import mysql_client
from cache import redis_client

router = APIRouter()


@router.get("/health")
def health():
    return {"status": "ok", "service": "api"}


@router.get("/health/redis")
def health_redis():
    try:
        redis_client.ping()
        return {"status": "ok", "dependency": "redis"}
    except Exception as e:
        return {"status": "unhealthy", "dependency": "redis", "error": str(e)}


@router.get("/health/database")
def health_database():
    try:
        mysql_client.ping()
        return {"status": "ok", "dependency": "mysql"}
    except Exception as e:
        return {"status": "unhealthy", "dependency": "mysql", "error": str(e)}
