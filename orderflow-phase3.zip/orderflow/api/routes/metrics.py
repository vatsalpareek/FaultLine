from fastapi import APIRouter
from config import settings
from telemetry import metrics

router = APIRouter()


@router.get("/metrics")
def get_metrics():
    return metrics.snapshot(
        redis_max=settings.REDIS_MAX_CONNECTIONS,
        db_max=settings.DB_MAX_CONNECTIONS,
    )
