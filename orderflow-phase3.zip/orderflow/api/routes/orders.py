from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database import mysql_client
from cache import redis_client

router = APIRouter()


class OrderRequest(BaseModel):
    product_id: int
    quantity: int


@router.post("/orders")
def create_order(order: OrderRequest):
    product = mysql_client.fetch_product(order.product_id)
    if not product:
        raise HTTPException(status_code=404, detail="product not found")
    if order.quantity < 1:
        raise HTTPException(status_code=400, detail="quantity must be at least 1")

    created = mysql_client.insert_order(order.product_id, order.quantity)
    redis_client.invalidate_product(order.product_id)  # cache invalidation, per spec section 3
    return created


@router.get("/orders/{order_id}")
def get_order(order_id: int):
    order = mysql_client.fetch_order(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="order not found")
    return order
