from fastapi import APIRouter, HTTPException
from database import mysql_client
from cache import redis_client

router = APIRouter()


@router.get("/products")
def list_products():
    cached = redis_client.get_all_products()
    if cached is not None:
        return {"source": "cache", "products": cached}

    products = mysql_client.fetch_all_products()
    # decimal -> float so it's JSON serializable
    for p in products:
        p["price"] = float(p["price"])
    redis_client.set_all_products(products)
    return {"source": "database", "products": products}


@router.get("/products/{product_id}")
def get_product(product_id: int):
    cached = redis_client.get_product(product_id)
    if cached is not None:
        return {"source": "cache", "product": cached}

    product = mysql_client.fetch_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="product not found")
    product["price"] = float(product["price"])
    redis_client.set_product(product_id, product)
    return {"source": "database", "product": product}
