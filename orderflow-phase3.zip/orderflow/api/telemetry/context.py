import contextvars

# Set once per request by the middleware; readable anywhere in that
# request's call chain (routes, cache client, db client) without having
# to pass request_id as a parameter through every function.
request_id_var = contextvars.ContextVar("request_id", default="-")
