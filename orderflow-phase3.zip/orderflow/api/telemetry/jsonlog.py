import json
import time

from telemetry.context import request_id_var


def log_event(
    service: str,
    operation: str,
    level: str = "INFO",
    dependency: str = None,
    latency_ms: float = None,
    status: str = "success",
    error: str = None,
):
    """Prints one JSON line per event to stdout. Docker captures stdout as
    the container's logs, so `docker compose logs` (or the terminal running
    `docker compose up`) shows these directly — no log file to go dig for."""
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
        "level": level,
        "service": service,
        "operation": operation,
        "request_id": request_id_var.get(),
        "status": status,
    }
    if dependency is not None:
        entry["dependency"] = dependency
    if latency_ms is not None:
        entry["latency_ms"] = round(latency_ms, 1)
    if error is not None:
        entry["error"] = error

    print(json.dumps(entry), flush=True)
