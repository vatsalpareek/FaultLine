import threading
import time

_lock = threading.Lock()

_state = {
    "api": {"requests": 0, "errors": 0, "timeouts": 0, "active": 0, "latency_total_ms": 0.0},
    "redis": {"ops": 0, "errors": 0, "timeouts": 0, "retries": 0, "active": 0, "latency_total_ms": 0.0},
    "mysql": {"queries": 0, "errors": 0, "active": 0, "latency_total_ms": 0.0},
    "started_at": time.time(),
}


def record_api_request(latency_ms: float, error: bool = False, timeout: bool = False):
    with _lock:
        _state["api"]["requests"] += 1
        _state["api"]["latency_total_ms"] += latency_ms
        if error:
            _state["api"]["errors"] += 1
        if timeout:
            _state["api"]["timeouts"] += 1


def api_active(delta: int):
    with _lock:
        _state["api"]["active"] += delta


def record_redis_op(latency_ms: float, error: bool = False, timeout: bool = False, retries: int = 0):
    with _lock:
        _state["redis"]["ops"] += 1
        _state["redis"]["latency_total_ms"] += latency_ms
        _state["redis"]["retries"] += retries
        if error:
            _state["redis"]["errors"] += 1
        if timeout:
            _state["redis"]["timeouts"] += 1


def redis_active(delta: int):
    with _lock:
        _state["redis"]["active"] += delta


def record_db_op(latency_ms: float, error: bool = False):
    with _lock:
        _state["mysql"]["queries"] += 1
        _state["mysql"]["latency_total_ms"] += latency_ms
        if error:
            _state["mysql"]["errors"] += 1


def db_active(delta: int):
    with _lock:
        _state["mysql"]["active"] += delta


def snapshot(redis_max: int, db_max: int):
    """Returns a plain dict, safe to JSON-serialize, for the /metrics route."""
    with _lock:
        api = dict(_state["api"])
        redis = dict(_state["redis"])
        mysql = dict(_state["mysql"])

    api["avg_latency_ms"] = round(api["latency_total_ms"] / api["requests"], 1) if api["requests"] else 0
    redis["avg_latency_ms"] = round(redis["latency_total_ms"] / redis["ops"], 1) if redis["ops"] else 0
    redis["max_connections"] = redis_max
    redis["saturation_pct"] = round(100 * redis["active"] / redis_max, 1) if redis_max else 0

    mysql["avg_latency_ms"] = round(mysql["latency_total_ms"] / mysql["queries"], 1) if mysql["queries"] else 0
    mysql["max_connections"] = db_max
    mysql["saturation_pct"] = round(100 * mysql["active"] / db_max, 1) if db_max else 0

    try:
        import psutil
        system = {
            "cpu_percent": psutil.cpu_percent(interval=0.1),
            "memory_percent": psutil.virtual_memory().percent,
        }
    except ImportError:
        system = {"cpu_percent": None, "memory_percent": None}

    return {
        "uptime_seconds": round(time.time() - _state["started_at"], 1),
        "api": api,
        "redis": redis,
        "mysql": mysql,
        "system": system,
    }
